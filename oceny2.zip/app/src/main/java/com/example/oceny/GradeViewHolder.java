package com.example.oceny;

import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class GradeViewHolder  extends RecyclerView.ViewHolder implements RadioGroup.OnCheckedChangeListener{
    private TextView subject;
    private Grade grade;
    private View itemView;
    private RadioGroup radioGroup;
    private int index;

    public GradeViewHolder(@NonNull View itemView) {
        super(itemView);
        this.itemView = itemView;
        subject = itemView.findViewById(R.id.subject);
        radioGroup = itemView.findViewById(R.id.radioGroup);
        setListener();
    }

    public void setRadioButtonState(){
        RadioButton radioButton = (RadioButton) radioGroup.getChildAt(grade.getGrade()-2);
        radioButton.setChecked(grade.isChecked());
        radioButton.setChecked(true);

    }

    private void setListener(){
        radioGroup.setOnCheckedChangeListener(this);
    }

    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {
        RadioButton radioButton = itemView.findViewById(checkedId);
        grade.setGrade(Integer.parseInt(radioButton.getText().toString()));
        grade.setChecked(!grade.isChecked());
    }

    public TextView getSubject() {
        return subject;
    }

    public void setSubject(TextView subject) {
        this.subject = subject;
    }

    public Grade getGrade() {
        return grade;
    }

    public void setGrade(Grade grade) {
        this.grade = grade;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
}
